/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jblas;

/**
 *
 * @author mikio
 */
public interface ConvertsToFloatMatrix {
    public FloatMatrix convertToFloatMatrix();
}
